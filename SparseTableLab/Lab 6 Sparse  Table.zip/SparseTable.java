/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sparsetablelab;

/**
 *
 * @author User
 */
public class SparseTable {
    RegisterNode[] students;
    RegisterNode[] classes;
    
    public SparseTable(int studentAmount, int classAmount){
        students = new RegisterNode[studentAmount];
        classes = new RegisterNode[classAmount];
    }
    
    public void addRegister(int newStudentId, int newClassId){
        if(!isRegister(newStudentId, newClassId)){
           RegisterNode newRegis = new RegisterNode(newStudentId, newClassId);
           RegisterNode temp;
           //student never register
           if(students[newStudentId] == null){
               students[newStudentId] = newRegis;
           }
           //new class will be the first class
           else if(newClassId < students[newStudentId].courseID){
               newRegis.nextClass = students[newStudentId];
               students[newClassId] = newRegis;
           }else{
           for(temp = students[newStudentId]; temp.nextClass != null && temp.nextClass.courseID < newClassId; temp = temp.nextClass){}
           newRegis.nextClass = temp.nextClass;
           temp.nextClass = newRegis;
           }
           //work among students in same class.
           if(classes[newClassId] == null){
               classes[newClassId] = newRegis;
           }
           //new class will be the first class
           else if(newStudentId < classes[newClassId].studentID){
               newRegis.nextStudent = classes[newClassId];
               classes[newStudentId] = newRegis;
           }else{
           for(temp = classes[newClassId]; temp.nextStudent != null && temp.nextStudent.studentID < newStudentId; temp = temp.nextStudent){}
           newRegis.nextStudent = temp.nextStudent;
           temp.nextStudent = newRegis;
           }
        }
    }
    
    public void printAllStudents(int classId){
        RegisterNode temp;
        for(temp = classes[classId]; temp != null; temp = temp.nextStudent){
            System.out.print(temp.studentID + " ");
        }
        System.out.println("");
    }
    
    public boolean isRegister(int studentId, int classId){
//        System.out.println("debug");
        RegisterNode temp;
        if(students[studentId] == null){
            return false;
        }else{
            for (temp = students[studentId]; temp != null && temp.courseID < classId; temp = temp.nextClass)
            {}
            if(temp == null || temp.courseID > classId){
                return false;
            }else{
                return true;
            }
        }
    }
    
    public void showAllClasses(int studentID){
        RegisterNode temp;
        for(temp = students[studentID]; temp != null; temp = temp.nextClass){
            System.out.print(temp.courseID + " ");
        }
        System.out.println("");
    }
}
